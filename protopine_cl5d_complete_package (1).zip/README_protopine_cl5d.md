
Protopine CL5D Complete Package
------------------------------

Files included:
- cl5d.py                          : Full ConsciousLeafModel implementation
- protopine_proteins.json          : Proteins JSON (records)
- protopine_compounds_top10.json   : Top-10 compounds JSON (records)
- protopine_cl5d_json_executed.ipynb : Executed notebook showing plots and CL5D sample run
- affinity_distribution.png
- top_proteins.png
- top_compounds.png

How to use:
1. Unzip the package.
2. Ensure Python environment has: pandas, numpy, scipy, matplotlib, nbformat.
   You can install with: pip install pandas numpy scipy matplotlib nbformat
3. Open the notebook in Jupyter to view results interactively.
