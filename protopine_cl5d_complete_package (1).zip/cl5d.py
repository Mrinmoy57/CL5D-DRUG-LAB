
\"\"\"cl5d.py
ConsciousLeaf 5D simplified Python module.
\"\"\"
import math
from math import factorial
from typing import List, Dict, Tuple
import numpy as np
from scipy.special import gamma

class ConsciousLeafModel:
    def __init__(self, hyperparams: Dict = None):
        self.hyper = {
            'lambda_T': 0.8, 'lambda_D': 0.7, 'beta': 3.0,
            'eta': 0.9, 'kappa': 0.45, 'n_shp': 12,
            'tau': 0.12, 'k_min': 6, 'k_max': 12,
            'cn_min': 0.000123, 'cn_top': 0.20, 'R': 20,
            'xi': 1.2, 'rho': 0.8
        }
        if hyperparams:
            self.hyper.update(hyperparams)

    def depth_transform(self, cn: float) -> float:
        cn_top = self.hyper['cn_top']
        cn_min = self.hyper['cn_min']
        cn = max(cn_min, min(1.0, cn))
        if cn >= cn_top:
            return 0.0
        num = math.log(cn_top / cn)
        den = math.log(cn_top / cn_min)
        return num / den

    def entropy(self, vals: List[float]) -> float:
        eps = 1e-9
        vals = [max(0.0, min(1.0, v)) for v in vals]
        s = sum(vals) + 4*eps
        probs = [(v+eps)/s for v in vals]
        return -sum(p*math.log(p) for p in probs if p>0)

    def shp(self, T: float, D: float) -> float:
        lamT = self.hyper['lambda_T']
        lamD = self.hyper['lambda_D']
        n = int(self.hyper['n_shp'])
        alpha = 1 + lamT * (1 - T)
        delta = lamD * (1 - D)
        return sum(1.0 / (alpha + k * delta) for k in range(n))

    def capacity(self, coords: Dict[str,float], D: float, H: float) -> float:
        avg_surface = (coords.get('At',0)+coords.get('Ab',0)+coords.get('Ex',0)+coords.get('T',0))/4.0
        gamma_term = gamma(1 + self.hyper['beta'] * D * avg_surface)
        entropy_term = math.exp(self.hyper['eta'] * H)
        return float(gamma_term * entropy_term)

    def apply_valence(self, V: float, C: float, SHP: float) -> float:
        return float(V * C * (1.0 + self.hyper['kappa'] * SHP))

    def permutation(self, n:int, m:int) -> float:
        if m>n: return 0.0
        return float(factorial(n)//factorial(n-m))

    def gate_agents(self, agents: List[Dict]) -> List[Dict]:
        active = []
        for a in agents:
            if (a.get('At',0) >= 0.7 or a.get('Ab',0)*a.get('H',0) >= 0.35 or
                a.get('Ex',0) >= 0.6 or a.get('T',0) >= 0.6 or a.get('D',0) >= 0.5):
                active.append(a)
        if not active:
            agents_sorted = sorted(agents, key=lambda x: x.get('Ct',0), reverse=True)
            active = agents_sorted[:8]
        return active

    def calculate_optimal_potential(self, active_agents: List[Dict]) -> Tuple[float,int]:
        phis = []
        R = int(self.hyper['R'])
        for m in range(1, len(active_agents)+1):
            top_m = sum(a.get('Ct',0) for a in active_agents[:m])
            perm = self.permutation(R, m)
            phi_m = top_m / perm if perm>0 else 0.0
            phis.append(phi_m)
        idx = int(np.argmax(phis)) if phis else 0
        return phis[idx] if phis else 0.0, idx+1

    def generate_prediction(self, phi_star: float, m_star: int) -> float:
        perm = self.permutation(int(self.hyper['R']), m_star)
        num = gamma(1 + self.hyper['xi'] * phi_star)
        den = 1.0 + self.hyper['rho'] * perm
        return float(num / den)

    def run(self, domain_valence: float, agents: List[Dict]) -> Tuple[float, List[Dict]]:
        Vd = max(0.0, min(1.0, domain_valence))
        processed = []
        for a in agents:
            D = self.depth_transform(a.get('Cn', 0.05))
            H = self.entropy([a.get('At',0), a.get('Ab',0), a.get('Ex',0), a.get('T',0)])
            SHP = self.shp(a.get('T',0), D)
            C = self.capacity(a, D, H)
            Ct = self.apply_valence(Vd, C, SHP)
            proc = dict(a)
            proc.update({'D':D,'H':H,'SHP':SHP,'C':C,'Ct':Ct})
            processed.append(proc)
        active = self.gate_agents(processed)
        phi_star, m_star = self.calculate_optimal_potential(active)
        pred = self.generate_prediction(phi_star, m_star)
        return pred, active[:m_star]

def map_to_coords_protein(row: Dict) -> Dict[str,float]:
    aff = row.get('Affinity_kcal_per_mol', 0.0)
    At = max(0.0, min(1.0, ( -aff ) / 8.0 ))
    diseases = row.get('Associated_Diseases','')
    n = len([d.strip() for d in diseases.split(',') if d.strip()])
    Ab = min(1.0, n/5.0)
    Ex = 1.0 if ('AlphaFold' not in str(row.get('PDB_ID',''))) else 0.6
    T = max(0.0, min(1.0, (abs(aff)/8.0)))
    Cn = max(0.000123, min(1.0, 1.0 - (At*0.5 + Ab*0.5)))
    return {'At':At, 'Ab':Ab, 'Ex':Ex, 'T':T, 'Cn':Cn}

def map_to_coords_compound(row: Dict) -> Dict[str,float]:
    score = float(row.get('score', 0.0))
    At = max(0.0, min(1.0, score))
    smi = str(row.get('smiles',''))
    Ab = min(1.0, len(smi)/80.0)
    Ex = 1.0 if ('1' in smi or 'c' in smi or 'C' in smi) else 0.5
    T = At
    Cn = max(0.000123, min(1.0, 1.0 - (At*0.4 + Ab*0.3 + Ex*0.3)))
    return {'At':At, 'Ab':Ab, 'Ex':Ex, 'T':T, 'Cn':Cn}
